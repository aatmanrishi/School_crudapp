import express from 'express';
import {join} from 'path';
import {connectDB} from './db/connectDB.js'
import router from './routers/web.js'

const app = express();
const port = process.env.PORT || 8000 ;
const dbUrl = process.env.dbUrl || "mongodb://localhost:27017";

connectDB(dbUrl);
app.use(express.urlencoded({extended:false}));

app.set('views','views');
app.set('view engine','ejs');
app.use('/edit',express.static(join(process.cwd(),'public')))
app.use(express.static(join(process.cwd(),'public')))


app.use('/',router);


app.listen(port,()=>{
    console.log("Server is running Smoothly on port : ",port);
});