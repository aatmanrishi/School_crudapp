import mongoose from 'mongoose';

const connectDB = async (Data_Base_URL)=>{
    try{
        const DB_Options = {
            dbName:'mySchoolDb'
        };
        await mongoose.connect(Data_Base_URL,DB_Options); 
        console.log("Connected Successfully");
    }catch(error){
      console.log(error);
    
    }
}

export {connectDB}