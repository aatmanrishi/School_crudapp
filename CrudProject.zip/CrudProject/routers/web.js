import express from 'express';
import {studentControllers} from '../controllers/studentControllers.js'
const router = express.Router();

router.get('/',studentControllers.getAllDoc);

router.post('/',studentControllers.createDoc);

router.post('/edit/:id',studentControllers.editDoc);

router.post('/update/:id',studentControllers.updateDocById);

router.post('/delete/:id', studentControllers.deleteDocById);


export default router ;